$(function () {

    const settings = {
        "async": true,
        "crossDomain": true,
        "url": "https://yahoo-weather5.p.rapidapi.com/weather?location=almaty&format=json&u=f",
        "method": "GET",
        "headers": {
            "X-RapidAPI-Key": "92210c1bf3mshc702c32ce06faccp1346aejsnaae94d0d108a",
            "X-RapidAPI-Host": "yahoo-weather5.p.rapidapi.com"
        }
    };

    let information;

    async function start() {
        await $.ajax(settings).done(function (response) {
            
        });
    }
    

    function createTemplate(params) {
        $('#info').append(widgetCurrentWeather(params));
    }

    function widgetCurrentWeather(params) {
        return `
        <div class="card" style="width: 50rem;">
                    <div class="card-body row">
                        <div class="container">
                            <div class="row justify-content-md-center">
                              <div class="col-sm">
                                <img src="..." class="rounded" alt="...">
                              </div>
                              <div class="col-sm">
                                ${params.current_observation.condition.temperature}
                              </div>
                              <div class="col-sm">
                                  <div>Sunrise</div>
                                  <div>Sunset</div>
                                  <div>Duration</div>
                              </div>
                            </div>
                          </div>
                    </div>
                </div>
        `;
    }

    function widgetHourly(params) {
        return `
        <div class="hourly">
                    <div class="container">
                        <div class="row">
                            <p>Hourly</p>
                          <div class="col-sm">
                            <div><p>Today</p></div>
                            <div><p></p></div>
                            <div><p>Forecast</p></div>
                            <div><p>Temp</p></div>
                            <div><p>RealFeel</p></div>
                            <div><p>Wind (km/h)</p></div>
                          </div>
                          <div class="col-sm">
                            
                          </div>
                          <div class="col-sm">
                            
                          </div>
                          <div class="col-sm">
                            
                          </div>
                          <div class="col-sm">
                            
                          </div>
                          <div class="col-sm">
                            
                          </div>
                        </div>
                      </div>

                        
                    </div>
                </div>
        `;
    }

    function widgetNearbyPlaces(params){
        return `
        <div class="">
                    <div class="row">
                        <div class="col-sm">
                            City
                        </div>
                        <div class="col-sm">
                            City
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm">
                            City
                        </div>
                        <div class="col-sm">
                            City
                        </div>
                    </div>
                </div>
        `;
    }
});



